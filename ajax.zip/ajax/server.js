const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware to parse JSON data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Array to store registered users
let usersArray = [];

// POST endpoint to handle user registration
// POST endpoint to handle user registration
app.post('/register', (req, res) => {
    const { name, surname, email, password, contact } = req.body;
  
    // Create a new user object
    const newUser = {
      name,
      surname,
      email,
      password,
      contact
    };
  
    // Add the new user to the array
    usersArray.push(newUser);
  
    // Send back the registered user data
    res.status(200).json(newUser);
  });
  
  

// GET endpoint to retrieve the list of registered users
app.get('/users', (req, res) => {
  res.status(200).json(usersArray);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
