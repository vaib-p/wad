function saveData() {
    const name = document.getElementById('name').value;
    const surname = document.getElementById('surname').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const contact = document.getElementById('contact').value;
  
    const userData = {
      name,
      surname,
      email,
      password,
      contact
    };
  
    // Send the user data to the server using AJAX POST
    fetch('/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(userData)
    })
    .then(response => response.json())
    .then(data => {
      console.log('Registration successful:', data);
      alert('Registration successful!');
      window.location.href = 'user-list.html'; // Redirect to the user list page
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Registration failed. Please try again.');
    });
  }
  