// Function to fetch and display user data list
function fetchUserDataList() {
    fetch('/users')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(usersData => {
      const userList = document.getElementById('userList');
      userList.innerHTML = ''; // Clear previous list items
  
      usersData.forEach(user => {
        const listItem = document.createElement('li');
        listItem.classList.add('list-group-item');
        listItem.textContent = `Name: ${user.name} ${user.surname}, Email: ${user.email}, Contact: ${user.contact}`;
        userList.appendChild(listItem);
      });
    })
    .catch(error => {
      console.error('Error fetching user data:', error);
    });
  }
  
  fetchUserDataList(); // Call the function to fetch and display user data list
  